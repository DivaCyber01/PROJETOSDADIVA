
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.sistema.sistemact.controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ControllerCt {
    public void salvar(StringBuilder dados, String arquivar){
        try{
            FileWriter fw = new FileWriter("arquivar",true);
            fw.write(dados.toString() + "\n");
        fw.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
}
